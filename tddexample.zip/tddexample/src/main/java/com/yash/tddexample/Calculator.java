package com.yash.tddexample;

public class Calculator {

	public int add(int i, int j) {
		// TODO Auto-generated method stub
		return i+j;
	}

}
