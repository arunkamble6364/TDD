package com.yash.mytddcalc;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import junit.framework.Assert;

public class TestCalculator 
{
	Calculator c=new Calculator();
	@Test
	public void test_StringCalculator_GivenEmptyString_ShouldReturnZero() {


		
		assertEquals(c.calculate("1"),1);
		
	}
    @Test
    public void test_StringCalculator_GivenSingleValue_ShouldReturnSingleValue() {
        
        
        assertEquals(c.calculate("2"),2);
    }
    
    @Test
    public void test_StringCalculator_GivenTwoValuesDelimitedByComma_ShouldReturnSum() {
        
        
        assertEquals(c.calculate(2,2),4);
    }



}
