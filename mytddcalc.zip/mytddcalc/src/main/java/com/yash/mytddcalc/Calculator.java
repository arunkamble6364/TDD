package com.yash.mytddcalc;

public class Calculator 
{

	public int calculate(String input) 
	{
		String [] numbers=input.split(",");

		if(isEmpty(input)) {
			return 0;
		}
		if(input.length()==1) {
			return stringtoInt(input);

		}
	else
	{
		return Integer.parseInt(numbers[0]) +Integer.parseInt(numbers[1]);
	}
	}


	private int stringtoInt(String input) {

		return Integer.parseInt(input);
	}

	private boolean isEmpty(String input) {

		return input.isEmpty();
	}

	public Object calculate(int i, int j) {

		return i+j;
	}




}
